from .base import *

DEBUG = False

ALLOWED_HOSTS = ['*']